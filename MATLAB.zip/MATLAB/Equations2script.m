F=3;
A=4;
Ti=2;
sim('Equations2')