Sim_time=300;
F=1;
M=18.5;
b=50;
k=20;
sim('Mass_Spring_System_Laplace_Domain')