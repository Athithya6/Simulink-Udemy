%%Load the data
Data = xlsread('Battery_Parameters.xlsx');

%%Name the variables
SOC=Data(:,1);
OCV=Data(:,2);
Charge_Res=Data(:,3);
Discharge_Res=Data(:,4);

%%Plot
plot(SOC,OCV);
figure

plot(SOC,Charge_Res);
figure

plot(SOC,Discharge_Res);

%%block parameters
I=3.6;
Cn=2.3*3600;
Sim_time=3600;
sim('Battery_System.slx');

