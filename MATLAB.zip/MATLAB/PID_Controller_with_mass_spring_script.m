%%first simulation
Sim_time=7;
Step_Value=1;
M=1;
b=10;
k=20;

%%define P controller parameters
Kp=200;
Ki=0;
Kd=0;
sim('PID_Controller_with_mass_spring')

%%PID Controller
% Kp=350;
% Ki=300;
% Kd=50;
% sim('PID_Controller_with_mass_spring')

%%plotting section
figure
plot(IN.time,IN.data)
hold all
plot(OUT.time,OUT.data)