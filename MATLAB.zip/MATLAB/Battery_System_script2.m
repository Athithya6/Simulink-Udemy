I = 3.6;
Cn = 2.3*3600;
Sim_time = 3600;
sim('Battery_System.slx');