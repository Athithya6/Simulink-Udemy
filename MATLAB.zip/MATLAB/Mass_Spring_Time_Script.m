Sim_time=150;
F=2;
k=30;
b=4;
M=15;
sim('Mass_Spring_System_Time_Domain');